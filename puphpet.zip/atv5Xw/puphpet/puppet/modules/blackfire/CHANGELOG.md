# 1.6.0 (2016.09.04)

* Ubuntu 16.04 support

# 1.5.2 (2016.04.22)

* Fix for `manage` parameter for `blackfire::php` (@Schnitzel)

# 1.5.1 (2016.03.08)

* Hotfix for `ini_path` (@Schnitzel)

# 1.5.0 (2016.03.07)

* Added new parameter `ini_path` (@Schnitzel)

# 1.4.2 (2016.03.03)

* Bound PE dependency

# 1.4.1 (2016.02.27)

* Update README and bound apt dependency

# 1.4.0 (2015.12.05)

* Puppet 4 compatibility
* Handle `log_level` passed as a string (@jtreminio)
* Added apt to manifest as a dependency 


# 1.3.0 (2015.06.01)

* Added support for puppetlabs-apt 2.0
* Added support for Debian 8
* CentOS bugfixes


# 1.2.2 (2015.04.08)

* Bugfixes


# 1.2.1 (2015.04.06)

* Fixed refreshes
* Debian 6 support

